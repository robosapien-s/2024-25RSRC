package org.firstinspires.ftc.teamcode.controllers;

public enum ETaskBlockingType {
    series,
    parallel
}
