package org.firstinspires.ftc.teamcode.interfaces;

public interface IImu {
    public double getHeading();
    public double getAbsoluteHeading();
}
