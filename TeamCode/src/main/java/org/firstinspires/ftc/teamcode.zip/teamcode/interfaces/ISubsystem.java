package org.firstinspires.ftc.teamcode.interfaces;

public interface ISubsystem {
    void initialize();
    void execute();
}
