package org.firstinspires.ftc.teamcode.robot;

public class Constants {
    public static boolean initialStateCalled = false;


    private static final double CLAW_UP = 0.3;
    private static final double CLAW_DOWN = 0.7;
    private static final double ROT_SERVO = 0.5;

   // private static final double

    public Constants(boolean initialStateCalled){
        this.initialStateCalled = initialStateCalled;

    }
}
